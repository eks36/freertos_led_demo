#include <stdio.h>
#include <unistd.h>
#include "hal_gpio.h"

#define LED_PIN 13

/* 
 * This simulates a FreeRTOS-style periodic task loop.
 * On real hardware you'd call vTaskDelay(pdMS_TO_TICKS(500)) instead of usleep().
 */
void blink_task(void){
    gpio_init(LED_PIN);
    while(1){
        gpio_toggle(LED_PIN);
        usleep(500000); // 500 ms
    }
}

int main(void){
    printf("Starting LED Blink Simulation...\n");
    blink_task();
    return 0;
}
