# FreeRTOS LED Blink (Simulation Starter)

This repository is a beginner-friendly embedded C project that *simulates* an LED blink task (similar to a FreeRTOS task) without requiring hardware. It uses a tiny HAL layer that prints GPIO changes to the console.

## Why this repo?
- Start directly **on GitHub** and then clone locally.
- Clean embedded-style structure: `src/`, `include/`, `simulate/`, `Makefile`.
- Easy to build and run on any PC with `gcc`.

## Build & Run
```bash
make
./blink_sim
```

### Expected Output
```
Starting LED Blink Simulation...
GPIO 13 initialized.
GPIO 13 toggled -> ON
GPIO 13 toggled -> OFF
...
```

## Next Steps
- Replace the simulated HAL with your board's HAL (STM32, ESP32, NXP, etc.).
- Swap `usleep()` with actual FreeRTOS `vTaskDelay()` calls on real hardware.
- Add more tasks (e.g., UART print task, sensor read task) and inter-task queues.
