#include <stdio.h>
#include "hal_gpio.h"

static int led_state = 0;

void gpio_init(int pin){
    printf("GPIO %d initialized.\n", pin);
}

void gpio_toggle(int pin){
    led_state = !led_state;
    printf("GPIO %d toggled -> %s\n", pin, led_state ? "ON" : "OFF");
}
