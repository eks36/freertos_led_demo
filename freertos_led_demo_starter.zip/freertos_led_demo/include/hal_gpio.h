#ifndef HAL_GPIO_H
#define HAL_GPIO_H

void gpio_init(int pin);
void gpio_toggle(int pin);

#endif
